<?php

/**
 * 
 * Include basic config file
 * 
 */
require 'Core/Config/config.php';

/**
 * 
 * Include autoload file
 * 
 */
require $GLOBALS['path']['core'].'autoload.php';